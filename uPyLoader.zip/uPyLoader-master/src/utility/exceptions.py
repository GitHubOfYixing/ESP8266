class PasswordException(Exception):
    pass


class NewPasswordException(Exception):
    pass


class OperationError(Exception):
    pass


class HostnameResolutionError(Exception):
    pass